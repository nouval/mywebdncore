

namespace ces.coreapi.sdk
{
    public class ValueData
    {
        public int Id;
        public string Value;
    }
}