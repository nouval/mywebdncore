<?php
$_['text_free_ship'] = 'Free Shipping';
?>
