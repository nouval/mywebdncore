Thanks for using this module.

----------------------------------------------------------------------------
Files Installation:
----------------------------------------------------------------------------

1. Extract downloaded free_ship_15.zip.

2. Upload all files from extracted "upload" folder in your opencart directory on the server.

----------------------------------------------------------------------------
Admin Installation:
----------------------------------------------------------------------------

Now install from admin -> Extensions -> Total -> Free ship


----------------------------------------------------------------------------
Support:
----------------------------------------------------------------------------

Please send comments in the module page of the opencart.com

Or you can send email to henadiy.kondratiuk@gmail.com for quick response.
