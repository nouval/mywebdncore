VQMOD Installation Procedure :

1. Download the latest version that has "opencart" in the title from
http://code.google.com/p/vqmod
2. Using FTP, upload the "vqmod" folder from the zip to the root of your opencart store.
3. Be sure the vqmod folder and the vqmod/vqcache folders are writable (either 755 or 777).
Also be sure index.php and admin/index.php are writable.
If not sure which you need, first try 755.
If you get errors about permissions, then try 777.
4. Goto http://www.yoursite.com/vqmod/install
5. You should get a success message. If not, check permissions above and try again
6. Load your store homepage and verify it works.
7. Using FTP, verify that there are new "vq" files in the "vqmod/vqcache" folder.
8. If yes, then you are ready to start downloading or creating vQmod scripts, otherwise ask for assistance.

Bulk Email & Promotion Template Installation Procedure :

1) Extract downloaded product and copy all folder from upload folder.
2) Paste all folders into your root directory.
3) Admin -> System -> Settings-> Click Edit link for default store setting
4) Find multiple tab for setting, at the end of the tab have server tab, click that server tab.
5) In server tab will find "Display Errors" if its selected "Yes" then return into "No" , It always should be "No"
6) Then "Extensions->Modules" and install "Email Promotion Template"


Demo : Admin

URL : http://ocdev.bullmarketplace.com/oc
--------------------------------------------------------------------------------

Username : demo
Password : demo@123


