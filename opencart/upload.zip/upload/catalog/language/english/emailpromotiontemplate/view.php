<?php
// Heading 
$_['heading_title']      = 'Template Preview';

// Text
$_['text_account']       = 'Template online View';
$_['text_template_not_found']    = 'Template not found';
?>