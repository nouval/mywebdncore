<?php

// Heading 
$_['heading_title']				= 'Custom Shipping Method';

// Text
$_['text_custom']				= 'Set Custom Shipping';

?>
