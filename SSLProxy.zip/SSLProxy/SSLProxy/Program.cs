﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;

namespace SSLProxy
{
    public class Program
    {
        static void Main(string[] args)
        {
            ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, policy) => { return true; };

            // starts remote web server
            var hostUri = @"http://localhost:8081/";
            RunHttpListener(hostUri);

            // starts proxy, listen to specific port, and forward it to remote web server
            var proxy = new Proxy();
            proxy.OnLogEvent += (message, item, sender) => { Console.WriteLine(message); };
            proxy.Run(4443, new Uri(hostUri), 8080);

            // start webclient and request html from proxy port!
            var webClient = new WebClient();
            var content = webClient.DownloadString("http://localhost:8080");

            // tests if we receive html as expected
            if (content.Equals(html))
            {
                Console.WriteLine("All good!");

                // start load test (parallel request), aginst secure port
                for (int loadTest = 0; loadTest < 100; loadTest++)
                {
                    var t = new Thread((counter) =>
                    {
                        var wc = new WebClient();
                        var ct = wc.DownloadString("https://localhost:4443");

                        if (ct.Equals(html))
                        {
                            Console.WriteLine("success-{0}", counter);
                        }
                    });
                    t.Start(loadTest);
                }

            }

            Console.ReadLine();
        }

        static IAsyncResult RunHttpListener(string prefix)
        {
            var httpListener = new HttpListener();
            httpListener.Prefixes.Add(prefix);
            httpListener.Start();
            Console.WriteLine("HttpListener started at port {0}", 8081);
            var asyncResult = httpListener.BeginGetContext(BeginGetContextCallback, httpListener);

            return asyncResult;
        }

        static void BeginGetContextCallback(IAsyncResult ar)
        {
            var httpListener = ar.AsyncState as HttpListener;

            httpListener.BeginGetContext(BeginGetContextCallback, httpListener);

            var context = httpListener.EndGetContext(ar);

            Console.WriteLine("(HttpListener) Connection from client: {0}", context.Request.RemoteEndPoint);

            var request = context.Request;
            var response = context.Response;
            
            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(html);
            response.ContentLength64 = buffer.Length;
            System.IO.Stream output = response.OutputStream;
            output.Write(buffer, 0, buffer.Length);
            output.Close();
        }

        static string html = "<html><head></head><body><strong>foo</strong>bar</body></html>";
    }
}
