﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace SSLProxy
{
    /// <summary>
    /// Triggered when data is received and available for processing
    /// </summary>
    /// <param name="data">received data</param>
    /// <param name="sender">from where this data was received (connection handler)</param>
    public delegate void DataReceiveDelegate(byte[] data, ConnectionHandler sender);

    /// <summary>
    /// Triggered when information is to be logged
    /// </summary>
    /// <param name="message">information to be logged</param>
    /// <param name="items">extended data to be logged in key,value form</param>
    /// <param name="sender">from where this data was send from</param>
    public delegate void LoggingDelegate(string message, Dictionary<string, object> items, object sender);

    /// <summary>
    /// Manages connection's stream lifecycle as well as send and receive data.
    /// </summary>
    public class ConnectionHandler
    {
        private TcpClient tcpClient;
        private Stream networkStream;
        private byte[] buffer;

        public event DataReceiveDelegate OnDataReceived;

        public event LoggingDelegate OnLogEvent;

        /// <summary>
        /// Default C'tor instantiating new object with given tcpClient and buffer size
        /// </summary>
        /// <param name="tcpClient">tcp connection</param>
        /// <param name="bufferSize">data size, per read</param>
        public ConnectionHandler(TcpClient tcpClient, int bufferSize = Constants.BufferSize)
            : this(tcpClient, tcpClient.GetStream(), bufferSize)
        {
        }

        /// <summary>
        /// Default C'tor instantiating new object with given tcpClient, custom stream and buffer size
        /// </summary>
        /// <param name="tcpClient">tcp connection</param>
        /// <param name="networkStream">connection stream</param>
        /// <param name="bufferSize">data size, per read</param>
        public ConnectionHandler(TcpClient tcpClient, Stream networkStream, int bufferSize = Constants.BufferSize)
        {
            this.tcpClient = tcpClient;
            this.networkStream = networkStream;
            this.buffer = new byte[bufferSize];
        }

        /// <summary>
        /// Starts reading from already established connection in asynchronous mode. To get received data, consuming client must add 
        /// callback object to <code>OnDataReceived</code> event.
        /// Throws InvalidOperationException, when connection is not ready to read
        /// </summary>
        public void ReadAsync()
        {
            if (!this.networkStream.CanRead)
            {
                throw new InvalidOperationException("Network stream cannot read data");
            }

            this.beginRead(beginReadCallback);
        }

        private void beginRead(AsyncCallback callback)
        {
            var asyncResult = this.networkStream.BeginRead(this.buffer, 0, buffer.Length, callback, this);
        }

        private void beginReadCallback(IAsyncResult ar)
        {
            var connHandler = ar.AsyncState as ConnectionHandler;

            var data = connHandler.endRead(ar);

            if (data == null)
            {
                connHandler.Close();
                return;
            }

            connHandler.beginRead(beginReadCallback);

            OnLogEvent?.Invoke(string.Format("Received: {0}", Encoding.ASCII.GetString(data)), null, this);
            OnDataReceived?.Invoke(data, this);
        }

        private byte[] endRead(IAsyncResult ar)
        {
            byte[] data = null;

            try
            {
                var bytesRead = this.networkStream.EndRead(ar);

                if (bytesRead != 0)
                {
                    data = new byte[bytesRead];
                    Array.Copy(this.buffer, data, bytesRead);
                }
            }
            catch (Exception ex)
            {
                OnLogEvent?.Invoke(string.Format("{0}\r\n{1}", ex.Message, ex.StackTrace), null, this);

                this.Close();
            }

            return data;
        }

        /// <summary>
        /// Write given data into connection in asynchronous mode.
        /// Throws InvalidOperationException, when connection is not ready for writing
        /// </summary>
        /// <param name="data"></param>
        public void WriteAsync(byte[] data)
        {
            if (!this.networkStream.CanWrite)
            {
                throw new InvalidOperationException("Network stream cannot write data");
            }

            beginWrite(data, beginWriteCallback);
        }

        private void beginWrite(byte[] data, AsyncCallback callback)
        {
            this.networkStream.BeginWrite(data, 0, data.Length, callback, this);
        }

        private void beginWriteCallback(IAsyncResult ar)
        {
            var connHandler = ar.AsyncState as ConnectionHandler;

            connHandler.endWrite(ar);
        }

        private void endWrite(IAsyncResult ar)
        {
            this.networkStream.EndWrite(ar);
        }

        /// <summary>
        /// Closing connection and stream.
        /// </summary>
        public void Close()
        {
            OnLogEvent?.Invoke("Closing connection", null, this);
            this.networkStream?.Close();
            this.tcpClient?.Close();
        }
    }

    /// <summary>
    /// Manages Tcp and Connection handler for each session.
    /// </summary>
    public class ProxyState
    {
        public ConnectionHandler ConnHandlerAsServer = null;
        public ConnectionHandler ConnHandlerAsClient = null;
        public ConnectionHandler ConnHandlerAsSslServer = null;

        /// <summary>
        /// Tcp object when Proxy act as consuming client to Remote Host (actual server)
        /// </summary>
        public TcpClient TcpAsClient = null;

        /// <summary>
        /// Tcp object when Proxy act as listening server for client (plain)
        /// </summary>
        public TcpClient TcpAsServer = null;

        /// <summary>
        /// Tcp object when Proxy act as listening server for client, over secure connecion (ssl)
        /// </summary>
        public TcpClient TcpAsSslServer = null;
        
        /// <summary>
        /// Secure connection, when Proxy listening as secure server.
        /// </summary>
        public SslStream SslStream = null;

        /// <summary>
        /// Unique identification, retrieve from client endpoint, e.g. ip and port.
        /// </summary>
        public string Key
        {
            get
            {
                return TcpAsServer?.Client.RemoteEndPoint.ToString() ?? TcpAsSslServer?.Client.RemoteEndPoint.ToString();
            }
        }
    }

    /// <summary>
    /// Just another static class holds constants, so we don't have any magic values
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Default file name of certificate
        /// </summary>
        public const string CertificateLocation = @"localhost.pfx";

        /// <summary>
        /// Default password to open certificate
        /// </summary>
        public const string CertificatePassword = "password";

        /// <summary>
        /// Default size of buffer
        /// </summary>
        public const int BufferSize = 1024;
    }

    /// <summary>
    /// The Proxy class, listen to specific port, both plain and secure and forward data to specific remote host.
    /// </summary>
    public class Proxy
    {
        private Hashtable proxyStates = new Hashtable();
        private string remoteHost;
        private int remotePort;
        private X509Certificate cert = null;

        /// <summary>
        /// Logging event callback
        /// </summary>
        public event LoggingDelegate OnLogEvent;

        /// <summary>
        /// Filename of ssl certificate, default to <code>Constants.CertificateLocation</code>
        /// </summary>
        public string CertificateFilename = Constants.CertificateLocation;

        /// <summary>
        /// Password to open ssl certificate, default to <code>Constants.CertificatePassword</code>
        /// </summary>
        public string CertifiatePassword = Constants.CertificatePassword;

        /// <summary>
        /// Instruct proxy object to begin listening at specific port. sslPort and port can't be the same.
        /// Throws InvalidOperationException when ports are the same value
        /// </summary>
        /// <param name="sslPort">listening ssl port</param>
        /// <param name="remoteServer">path to remote host</param>
        /// <param name="port">listening port (unsecure)</param>
        public void Run(int sslPort, Uri remoteServer, int port = 0)
        {
            if (sslPort == port && sslPort == remoteServer.Port)
            {
                throw new InvalidOperationException("Proxy must listen on different port");
            }

            Run(sslPort, remoteServer.Host, remoteServer.Port, port);
        }

        /// <summary>
        /// Instruct proxy object to begin listening at specific port. sslPort and port can't be the same.
        /// Both ssl and unsecure server will be started here. No unsecure server will be started 
        /// IF <paramref name="port"/> is set to 0 (default value).
        /// Throws InvalidOperationException when ports are the same value
        /// </summary>
        /// <param name="sslPort">listening ssl port</param>
        /// <param name="remoteHost">remote hostname or ip address</param>
        /// <param name="remotePort">remote host port</param>
        /// <param name="port">listening port (unsecure)</param>
        public void Run(int sslPort, string remoteHost, int remotePort, int port = 0)
        {
            this.remoteHost = remoteHost;
            this.remotePort = remotePort;

            runAsSslServer(sslPort);

            // only run plain socket if port is not 0
            if (port != 0)
                runAsServer(port);
        }

        /// <summary>
        /// This will setup ProxyState, connection handler and instruct it to begin reading.
        /// Sequence must be honour or it risking data not being exchange properly.
        /// 1st setup and manage connection handler between Proxy and Remote Server
        /// 2nd setup and manage connection handler between Client and Proxy (both plain and secure)
        /// </summary>
        /// <param name="ps"></param>
        /// <param name="onLogging"></param>
        private void process(ProxyState ps, LoggingDelegate onLogging = null)
        {
            if (ps.TcpAsClient != null)
            {
                ps.ConnHandlerAsClient = new ConnectionHandler(ps.TcpAsClient);
                ps.ConnHandlerAsClient.OnLogEvent += onLogging;
                ps.ConnHandlerAsClient.OnDataReceived += (data, sender) =>
                {
                    ps.ConnHandlerAsServer?.WriteAsync(data);
                    ps.ConnHandlerAsSslServer?.WriteAsync(data);
                };

                ps.ConnHandlerAsClient.ReadAsync();
            }

            if (ps.SslStream != null)
            {
                ps.ConnHandlerAsSslServer = new ConnectionHandler(ps.TcpAsSslServer, ps.SslStream);
                ps.ConnHandlerAsSslServer.OnLogEvent += onLogging;
                ps.ConnHandlerAsSslServer.OnDataReceived += (data, sender) =>
                {
                    ps.ConnHandlerAsClient?.WriteAsync(data);
                };

                ps.ConnHandlerAsSslServer.ReadAsync();
            }

            if (ps.TcpAsServer != null)
            {
                ps.ConnHandlerAsServer = new ConnectionHandler(ps.TcpAsServer);
                ps.ConnHandlerAsServer.OnLogEvent += onLogging;
                ps.ConnHandlerAsServer.OnDataReceived += (data, sender) =>
                {
                    ps.ConnHandlerAsClient?.WriteAsync(data);
                };

                ps.ConnHandlerAsServer.ReadAsync();
            }
        }

        /// <summary>
        /// runAsClient means connect to Remote Host
        /// </summary>
        /// <param name="host"></param>
        /// <param name="port"></param>
        /// <param name="ps"></param>
        /// <returns></returns>
        private IAsyncResult runAsClient(string host, int port, ProxyState ps)
        {
            TcpClient tcpClient = new TcpClient();

            ps.TcpAsClient = tcpClient;

            var asyncResult = tcpClient.BeginConnect(host, port, runAsClient_BeginConnectCalback, ps);

            return asyncResult;
        }

        private void runAsClient_BeginConnectCalback(IAsyncResult ar)
        {
            var ps = ar.AsyncState as ProxyState;
            var tcpClient = ps?.TcpAsClient;

            if (tcpClient.Connected)
            {
                proxyStates.Add(ps.Key, ps); // add proxyState into list (for stats)
                process(ps);
            }

            OnLogEvent?.Invoke(string.Format("Connected to {0}", tcpClient.Client.RemoteEndPoint), null, this);

            tcpClient.EndConnect(ar);
        }

        /// <summary>
        /// runAsServer means listening as unsecure server
        /// </summary>
        /// <param name="port"></param>
        /// <returns></returns>
        private IAsyncResult runAsServer(int port)
        {
            TcpListener tcpListener = new TcpListener(new IPEndPoint(IPAddress.Any, port));
            tcpListener.Start();
            var asyncResult = tcpListener.BeginAcceptTcpClient(runAsServer_BeginAcceptTcpClientCallback, tcpListener);

            OnLogEvent?.Invoke(string.Format("TcpListener started on port: {0}", port), null, this);

            return asyncResult;
        }

        private void runAsServer_BeginAcceptTcpClientCallback(IAsyncResult ar)
        {
            var tcpListener = ar.AsyncState as TcpListener;
            tcpListener.BeginAcceptTcpClient(runAsServer_BeginAcceptTcpClientCallback, tcpListener);

            var tcpClient = tcpListener.EndAcceptTcpClient(ar);

            OnLogEvent?.Invoke(string.Format("New client from {0} is connected", tcpClient.Client.RemoteEndPoint), null, this);

            if (tcpClient.Connected)
            {
                runAsClient(
                    this.remoteHost,
                    this.remotePort,
                    new ProxyState()
                    {
                        TcpAsServer = tcpClient
                    });
            }
        }

        /// <summary>
        /// runAsSslServer means listening as secure server
        /// </summary>
        /// <param name="sslPort"></param>
        /// <returns></returns>
        private IAsyncResult runAsSslServer(int sslPort)
        {
            TcpListener tcpListener = new TcpListener(new IPEndPoint(IPAddress.Any, sslPort));
            tcpListener.Start();
            var asyncResult = tcpListener.BeginAcceptTcpClient(runAsSSLServer_BeginAcceptTcpClientCallback, tcpListener);

            OnLogEvent?.Invoke(string.Format("TcpListener (SSL) started on port: {0}", sslPort), null, null);

            return asyncResult;
        }

        private void runAsSSLServer_BeginAcceptTcpClientCallback(IAsyncResult ar)
        {
            var tcpListener = ar.AsyncState as TcpListener;
            tcpListener.BeginAcceptTcpClient(runAsSSLServer_BeginAcceptTcpClientCallback, tcpListener);

            var tcpClient = tcpListener.EndAcceptTcpClient(ar);

            var sslStream = new SslStream(tcpClient.GetStream(), true);
            sslStream.BeginAuthenticateAsServer(Certificate, false, SslProtocols.Default, false, sslStream_BeginAuthenticateAsServer,
                new ProxyState()
                {
                    TcpAsSslServer = tcpClient,
                    SslStream = sslStream
                });
        }

        private void sslStream_BeginAuthenticateAsServer(IAsyncResult ar)
        {
            var ps = ar.AsyncState as ProxyState;

            try
            {
                var sslStream = ps.SslStream;
                sslStream.EndAuthenticateAsServer(ar);

                runAsClient(
                    this.remoteHost,
                    this.remotePort,
                    ps);
            }
            catch (Exception ex)
            {
                OnLogEvent?.Invoke(string.Format("{0}\n\r{1}", ex.Message, ex.StackTrace), null, this);
                ps.SslStream.Close();
                ps.TcpAsSslServer.Close();
            }
        }

        private X509Certificate Certificate
        {
            get
            {
                if (cert == null)
                {
                    try
                    {
                        X509Certificate2Collection collection = new X509Certificate2Collection();
                        collection.Import(Constants.CertificateLocation, Constants.CertificatePassword, X509KeyStorageFlags.PersistKeySet);

                        cert = collection[0];
                    }
                    catch (Exception ex)
                    {
                        OnLogEvent?.Invoke(string.Format("{0}\r\n{1}", ex.Message, ex.StackTrace), null, this);
                    }
                }

                return cert;
            }
        }
    }
}
